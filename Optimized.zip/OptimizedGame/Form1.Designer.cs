﻿namespace OptimizedGame
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            tableLayoutPanel1 = new TableLayoutPanel();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.LemonChiffon;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Inset;
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Controls.Add(label16, 3, 3);
            tableLayoutPanel1.Controls.Add(label15, 2, 3);
            tableLayoutPanel1.Controls.Add(label14, 1, 3);
            tableLayoutPanel1.Controls.Add(label13, 0, 3);
            tableLayoutPanel1.Controls.Add(label12, 3, 2);
            tableLayoutPanel1.Controls.Add(label11, 2, 2);
            tableLayoutPanel1.Controls.Add(label10, 1, 2);
            tableLayoutPanel1.Controls.Add(label9, 0, 2);
            tableLayoutPanel1.Controls.Add(label8, 3, 1);
            tableLayoutPanel1.Controls.Add(label7, 2, 1);
            tableLayoutPanel1.Controls.Add(label6, 1, 1);
            tableLayoutPanel1.Controls.Add(label5, 0, 1);
            tableLayoutPanel1.Controls.Add(label4, 3, 0);
            tableLayoutPanel1.Controls.Add(label3, 2, 0);
            tableLayoutPanel1.Controls.Add(label2, 1, 0);
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Size = new Size(534, 511);
            tableLayoutPanel1.TabIndex = 0;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // label16
            // 
            label16.Dock = DockStyle.Fill;
            label16.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label16.Location = new Point(404, 383);
            label16.Name = "label16";
            label16.Size = new Size(125, 126);
            label16.TabIndex = 15;
            label16.Text = "c";
            label16.TextAlign = ContentAlignment.MiddleCenter;
            label16.Click += label6_Click;
            // 
            // label15
            // 
            label15.Dock = DockStyle.Fill;
            label15.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label15.Location = new Point(271, 383);
            label15.Name = "label15";
            label15.Size = new Size(125, 126);
            label15.TabIndex = 14;
            label15.Text = "c";
            label15.TextAlign = ContentAlignment.MiddleCenter;
            label15.Click += label6_Click;
            // 
            // label14
            // 
            label14.Dock = DockStyle.Fill;
            label14.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label14.Location = new Point(138, 383);
            label14.Name = "label14";
            label14.Size = new Size(125, 126);
            label14.TabIndex = 13;
            label14.Text = "c";
            label14.TextAlign = ContentAlignment.MiddleCenter;
            label14.Click += label6_Click;
            // 
            // label13
            // 
            label13.Dock = DockStyle.Fill;
            label13.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label13.Location = new Point(5, 383);
            label13.Name = "label13";
            label13.Size = new Size(125, 126);
            label13.TabIndex = 12;
            label13.Text = "c";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            label13.Click += label6_Click;
            // 
            // label12
            // 
            label12.Dock = DockStyle.Fill;
            label12.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label12.Location = new Point(404, 256);
            label12.Name = "label12";
            label12.Size = new Size(125, 125);
            label12.TabIndex = 11;
            label12.Text = "c";
            label12.TextAlign = ContentAlignment.MiddleCenter;
            label12.Click += label6_Click;
            // 
            // label11
            // 
            label11.Dock = DockStyle.Fill;
            label11.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label11.Location = new Point(271, 256);
            label11.Name = "label11";
            label11.Size = new Size(125, 125);
            label11.TabIndex = 10;
            label11.Text = "c";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            label11.Click += label6_Click;
            // 
            // label10
            // 
            label10.Dock = DockStyle.Fill;
            label10.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label10.Location = new Point(138, 256);
            label10.Name = "label10";
            label10.Size = new Size(125, 125);
            label10.TabIndex = 9;
            label10.Text = "c";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            label10.Click += label6_Click;
            // 
            // label9
            // 
            label9.Dock = DockStyle.Fill;
            label9.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label9.Location = new Point(5, 256);
            label9.Name = "label9";
            label9.Size = new Size(125, 125);
            label9.TabIndex = 8;
            label9.Text = "c";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            label9.Click += label6_Click;
            // 
            // label8
            // 
            label8.Dock = DockStyle.Fill;
            label8.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label8.Location = new Point(404, 129);
            label8.Name = "label8";
            label8.Size = new Size(125, 125);
            label8.TabIndex = 7;
            label8.Text = "c";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            label8.Click += label6_Click;
            // 
            // label7
            // 
            label7.Dock = DockStyle.Fill;
            label7.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label7.Location = new Point(271, 129);
            label7.Name = "label7";
            label7.Size = new Size(125, 125);
            label7.TabIndex = 6;
            label7.Text = "c";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            label7.Click += label6_Click;
            // 
            // label6
            // 
            label6.Dock = DockStyle.Fill;
            label6.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label6.Location = new Point(138, 129);
            label6.Name = "label6";
            label6.Size = new Size(125, 125);
            label6.TabIndex = 5;
            label6.Text = "c";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            label6.Click += label6_Click;
            // 
            // label5
            // 
            label5.Dock = DockStyle.Fill;
            label5.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label5.Location = new Point(5, 129);
            label5.Name = "label5";
            label5.Size = new Size(125, 125);
            label5.TabIndex = 4;
            label5.Text = "c";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            label5.Click += label6_Click;
            // 
            // label4
            // 
            label4.Dock = DockStyle.Fill;
            label4.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label4.Location = new Point(404, 2);
            label4.Name = "label4";
            label4.Size = new Size(125, 125);
            label4.TabIndex = 3;
            label4.Text = "c";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            label4.Click += label6_Click;
            // 
            // label3
            // 
            label3.Dock = DockStyle.Fill;
            label3.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label3.Location = new Point(271, 2);
            label3.Name = "label3";
            label3.Size = new Size(125, 125);
            label3.TabIndex = 2;
            label3.Text = "c";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            label3.Click += label6_Click;
            // 
            // label2
            // 
            label2.Dock = DockStyle.Fill;
            label2.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label2.Location = new Point(138, 2);
            label2.Name = "label2";
            label2.Size = new Size(125, 125);
            label2.TabIndex = 1;
            label2.Text = "c";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            label2.Click += label6_Click;
            // 
            // label1
            // 
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Webdings", 48F, FontStyle.Regular, GraphicsUnit.Point, 2);
            label1.Location = new Point(5, 2);
            label1.Name = "label1";
            label1.Size = new Size(125, 125);
            label1.TabIndex = 0;
            label1.Text = "c";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            label1.Click += label6_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(534, 511);
            Controls.Add(tableLayoutPanel1);
            Name = "Form1";
            Text = "Form1";
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private System.Windows.Forms.Timer timer1;
    }
}
