﻿namespace Memory
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            tableLayoutPanel1 = new TableLayoutPanel();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.CornflowerBlue;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Inset;
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Controls.Add(label16, 3, 3);
            tableLayoutPanel1.Controls.Add(label15, 2, 3);
            tableLayoutPanel1.Controls.Add(label14, 1, 3);
            tableLayoutPanel1.Controls.Add(label13, 0, 3);
            tableLayoutPanel1.Controls.Add(label12, 3, 2);
            tableLayoutPanel1.Controls.Add(label11, 2, 2);
            tableLayoutPanel1.Controls.Add(label10, 1, 2);
            tableLayoutPanel1.Controls.Add(label9, 0, 2);
            tableLayoutPanel1.Controls.Add(label8, 3, 1);
            tableLayoutPanel1.Controls.Add(label7, 2, 1);
            tableLayoutPanel1.Controls.Add(label6, 1, 1);
            tableLayoutPanel1.Controls.Add(label5, 0, 1);
            tableLayoutPanel1.Controls.Add(label4, 3, 0);
            tableLayoutPanel1.Controls.Add(label3, 2, 0);
            tableLayoutPanel1.Controls.Add(label2, 1, 0);
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Size = new Size(662, 566);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Dock = DockStyle.Fill;
            label16.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label16.Location = new Point(500, 425);
            label16.Name = "label16";
            label16.Size = new Size(157, 139);
            label16.TabIndex = 15;
            label16.Text = "N";
            label16.TextAlign = ContentAlignment.MiddleCenter;
            label16.UseCompatibleTextRendering = true;
            label16.UseMnemonic = false;
            label16.Click += label4_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Dock = DockStyle.Fill;
            label15.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label15.Location = new Point(335, 425);
            label15.Name = "label15";
            label15.Size = new Size(157, 139);
            label15.TabIndex = 14;
            label15.Text = "N";
            label15.TextAlign = ContentAlignment.MiddleCenter;
            label15.UseCompatibleTextRendering = true;
            label15.UseMnemonic = false;
            label15.Click += label4_Click;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Dock = DockStyle.Fill;
            label14.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label14.Location = new Point(170, 425);
            label14.Name = "label14";
            label14.Size = new Size(157, 139);
            label14.TabIndex = 13;
            label14.Text = "N";
            label14.TextAlign = ContentAlignment.MiddleCenter;
            label14.UseCompatibleTextRendering = true;
            label14.UseMnemonic = false;
            label14.Click += label4_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Dock = DockStyle.Fill;
            label13.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label13.Location = new Point(5, 425);
            label13.Name = "label13";
            label13.Size = new Size(157, 139);
            label13.TabIndex = 12;
            label13.Text = "N";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            label13.UseCompatibleTextRendering = true;
            label13.UseMnemonic = false;
            label13.Click += label4_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Dock = DockStyle.Fill;
            label12.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label12.Location = new Point(500, 284);
            label12.Name = "label12";
            label12.Size = new Size(157, 139);
            label12.TabIndex = 11;
            label12.Text = "N";
            label12.TextAlign = ContentAlignment.MiddleCenter;
            label12.UseCompatibleTextRendering = true;
            label12.UseMnemonic = false;
            label12.Click += label4_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Dock = DockStyle.Fill;
            label11.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label11.Location = new Point(335, 284);
            label11.Name = "label11";
            label11.Size = new Size(157, 139);
            label11.TabIndex = 10;
            label11.Text = "N";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            label11.UseCompatibleTextRendering = true;
            label11.UseMnemonic = false;
            label11.Click += label4_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Dock = DockStyle.Fill;
            label10.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label10.Location = new Point(170, 284);
            label10.Name = "label10";
            label10.Size = new Size(157, 139);
            label10.TabIndex = 9;
            label10.Text = "N";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            label10.UseCompatibleTextRendering = true;
            label10.UseMnemonic = false;
            label10.Click += label4_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Dock = DockStyle.Fill;
            label9.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label9.Location = new Point(5, 284);
            label9.Name = "label9";
            label9.Size = new Size(157, 139);
            label9.TabIndex = 8;
            label9.Text = "N";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            label9.UseCompatibleTextRendering = true;
            label9.UseMnemonic = false;
            label9.Click += label4_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Dock = DockStyle.Fill;
            label8.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label8.Location = new Point(500, 143);
            label8.Name = "label8";
            label8.Size = new Size(157, 139);
            label8.TabIndex = 7;
            label8.Text = "N";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            label8.UseCompatibleTextRendering = true;
            label8.UseMnemonic = false;
            label8.Click += label4_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Dock = DockStyle.Fill;
            label7.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label7.Location = new Point(335, 143);
            label7.Name = "label7";
            label7.Size = new Size(157, 139);
            label7.TabIndex = 6;
            label7.Text = "N";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            label7.UseCompatibleTextRendering = true;
            label7.UseMnemonic = false;
            label7.Click += label4_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Dock = DockStyle.Fill;
            label6.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label6.Location = new Point(170, 143);
            label6.Name = "label6";
            label6.Size = new Size(157, 139);
            label6.TabIndex = 5;
            label6.Text = "N";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            label6.UseCompatibleTextRendering = true;
            label6.UseMnemonic = false;
            label6.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Dock = DockStyle.Fill;
            label5.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label5.Location = new Point(5, 143);
            label5.Name = "label5";
            label5.Size = new Size(157, 139);
            label5.TabIndex = 4;
            label5.Text = "N";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            label5.UseCompatibleTextRendering = true;
            label5.UseMnemonic = false;
            label5.Click += label4_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Fill;
            label4.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label4.Location = new Point(500, 2);
            label4.Name = "label4";
            label4.Size = new Size(157, 139);
            label4.TabIndex = 3;
            label4.Text = "N";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            label4.UseCompatibleTextRendering = true;
            label4.UseMnemonic = false;
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Fill;
            label3.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label3.Location = new Point(335, 2);
            label3.Name = "label3";
            label3.Size = new Size(157, 139);
            label3.TabIndex = 2;
            label3.Text = "N";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            label3.UseCompatibleTextRendering = true;
            label3.UseMnemonic = false;
            label3.Click += label4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Fill;
            label2.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label2.Location = new Point(170, 2);
            label2.Name = "label2";
            label2.Size = new Size(157, 139);
            label2.TabIndex = 1;
            label2.Text = "N";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            label2.UseCompatibleTextRendering = true;
            label2.UseMnemonic = false;
            label2.Click += label4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Webdings", 48F, FontStyle.Bold, GraphicsUnit.Point, 2);
            label1.Location = new Point(5, 2);
            label1.Name = "label1";
            label1.Size = new Size(157, 139);
            label1.TabIndex = 0;
            label1.Text = "N";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            label1.UseCompatibleTextRendering = true;
            label1.UseMnemonic = false;
            label1.Click += label4_Click;
            // 
            // timer1
            // 
            timer1.Interval = 750;
            timer1.Tick += timer1_Tick;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AliceBlue;
            ClientSize = new Size(662, 566);
            Controls.Add(tableLayoutPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Memory Game";
            Load += Form2_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private System.Windows.Forms.Timer timer1;
    }
}